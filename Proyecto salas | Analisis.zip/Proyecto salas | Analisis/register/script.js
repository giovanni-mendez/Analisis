const Error = document.getElementById("Error")
const Boton = document.getElementById("Boton")

// Selecciona el elemento en el que quieres detectar el clic
const miBoton = document.getElementById('miBoton');



// Agrega un listener para el evento 'click'
miBoton.addEventListener('click', function() {
    // Aquí va el código que quieres ejecutar cuando se haga clic en el botón
    
});

